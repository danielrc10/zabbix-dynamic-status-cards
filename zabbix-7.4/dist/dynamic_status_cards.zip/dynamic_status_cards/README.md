# Cards de status dinâmicos / Dynamic Status Cards

[Português](#português) · [English](#english)

## Português

Widget genérico para Zabbix 7.4 que agrupa itens por uma tag e reúne várias métricas no mesmo card. Ele usa a API interna do frontend, respeita as permissões do usuário conectado e não armazena credenciais adicionais.

### Instalação

Use o instalador do projeto ou copie esta pasta para o diretório `modules` do frontend:

```text
/usr/share/zabbix/modules/dynamic_status_cards
```

Depois acesse **Administração → Geral → Módulos**, escaneie o diretório e habilite **Cards de status dinâmicos**. Em containers, instale no container do frontend, não no Zabbix Server ou Agent 2.

### Configuração

- **Grupos de hosts:** carrega dinamicamente todos os hosts monitorados do grupo e de seus subgrupos.
- **Hosts:** filtro adicional opcional; vazio, permite que novos hosts do grupo apareçam automaticamente.
- **Tags de host:** filtro E/OU ou Ou aplicado aos hosts, como no Honeycomb nativo.
- **Etiquetas de itens:** filtro E/OU ou Ou aplicado antes dos padrões de cada métrica.
- **Tag usada para agrupar:** cada valor diferente gera um card; vazia, gera um card por host.
- **Métricas exibidas:** use **Adicionar métrica** e configure tudo pela interface, sem JSON.
- **Copiar métrica:** duplica toda a configuração em uma nova métrica pronta para ajustes.
- **Reordenar:** arraste a alça da primeira coluna para definir a ordem exibida nos cards.
- **Tipos de linha:** métrica, espaço vazio com altura de uma linha ou separador horizontal.
- **Nome da métrica:** pode ser ocultado no card e continua disponível no editor.
- **Item ou padrão:** aceita itens selecionados e `*` como curinga no nome completo.
- **Item complementar:** exibe valor principal e complementar como `usado / total`.
- **Texto entre valores:** personaliza `/`, ` / `, ` de ` ou outro separador curto.
- **Percentual calculado:** pode avaliar a cor por `principal ÷ complementar × 100`.
- **Item alternativo de estado:** permite exibir um item e usar outro item do mesmo card para definir a cor.
- **Item de disponibilidade:** força crítico e pode mostrar `Indisponível` quando outro item, como `Ping Ativo`, vale `0`.
- **Limiares numéricos:** permitem escolher se valores maiores ou menores representam pior estado.
- **Valores exatos:** associam listas de valores aos estados OK, aviso e crítico.
- **Histórico:** mostra o valor atual com uma barra histórica ou somente a barra, em períodos de 1 a 90 dias; novas métricas usam 1 dia por padrão.
- **Eixo histórico:** mostra início, ponto médio e Agora; nome e resumo percentual são opcionais.
- **Cores históricas:** OK, aviso, crítico, indisponível e sem dados podem herdar a paleta ou ser personalizadas por métrica.
- **Cores:** OK, aviso, crítico e sem dados são personalizáveis no formulário principal.
- **Fundo:** automático, transparente, sólido ou gradiente configurável.
- **Texto:** automático com contraste, claro, escuro ou cor personalizada.
- **Estado geral:** apresenta o pior estado encontrado nas linhas.

Formatos: `automatico`, `mapa`, `numero`, `percentual_fracao`, `data` e `texto`. O formato `percentual_fracao` converte `0.4475` em `44,75%` e aplica a mesma escala aos limiares do item principal.

Estados atuais: `ok`, `aviso`, `critico`, `sem_dados` e `neutro`. A barra também distingue `indisponivel`.

A barra histórica usa itens numéricos, consulta a retenção de histórico do Zabbix e agrega o período em até 180 blocos. O resumo opcional calcula disponibilidade quando há um item de disponibilidade ou o percentual OK nos demais casos. O LED atual continua baseado somente na amostra mais recente. Períodos acima de 24 horas podem ficar mais lentos, pois são consultados novamente em cada atualização do dashboard.

A configuração é salva em campos estruturados do dashboard. Configurações JSON criadas pela versão 1.0 são convertidas ao abrir e salvar o widget.

## English

Generic Zabbix 7.4 widget that groups items by a tag and combines multiple metrics in the same card. It uses the internal frontend API, respects the logged-in user's permissions, and stores no additional credentials.

### Installation

Use the project installer or copy this directory to the frontend `modules` directory:

```text
/usr/share/zabbix/modules/dynamic_status_cards
```

Then go to **Administration → General → Modules**, scan the directory, and enable **Cards de status dinâmicos**. For containers, install it in the frontend container, not in the Zabbix Server or Agent 2 container.

### Configuration

- **Host groups:** dynamically loads every monitored host from the group and its subgroups.
- **Hosts:** optional additional filter; empty allows new group members to appear automatically.
- **Host tags:** And/Or or Or host filtering, matching the native Honeycomb behavior.
- **Item tags:** And/Or or Or filtering applied before each metric pattern.
- **Grouping tag:** each distinct value creates one card; empty creates one card per host.
- **Displayed metrics:** use **Adicionar métrica** and configure everything in the GUI without JSON.
- **Copy metric:** duplicates every setting into a new metric ready to be adjusted.
- **Reorder:** drag the first-column handle to define card display order.
- **Row types:** metric, one-row empty space, or horizontal separator.
- **Metric name:** can be hidden on the card while remaining available in the editor.
- **Item or pattern:** accepts selected items and `*` as a wildcard in the full item name.
- **Complementary item:** displays primary and complementary values as `used / total`.
- **Text between values:** customizes `/`, ` / `, ` de `, or another short separator.
- **Calculated percentage:** can evaluate color using `primary ÷ complementary × 100`.
- **Alternate state item:** displays one item while another item in the same card determines the color.
- **Availability item:** forces critical and can display `Indisponível` when another item, such as `Ping Ativo`, is `0`.
- **Numeric thresholds:** support both higher-is-worse and lower-is-worse evaluation.
- **Exact values:** associate value lists with OK, warning, and critical states.
- **History:** displays the current value plus a historical status bar or only the bar, over 1 to 90 days; new metrics default to 1 day.
- **Historical axis:** shows start, temporal midpoint, and Agora; metric name and percentage summary are optional.
- **Historical colors:** OK, warning, critical, unavailable, and no data can inherit the palette or be customized per metric.
- **Colors:** OK, warning, critical, and no-data colors are configurable in the main form.
- **Background:** automatic, transparent, solid, or configurable gradient.
- **Text:** automatic contrast, light, dark, or a custom color.
- **Overall state:** displays the worst state found among the rows.

Formats: `automatico`, `mapa`, `numero`, `percentual_fracao`, `data`, and `texto`. The `percentual_fracao` format converts `0.4475` into `44,75%` and applies the same scale to primary-item thresholds.

Current states: `ok`, `aviso`, `critico`, `sem_dados`, and `neutro`. The bar also distinguishes `indisponivel`.

The historical bar uses numeric items, reads Zabbix history retention, and aggregates the period into at most 180 buckets. Its optional summary calculates availability when an availability item exists, or the OK percentage otherwise. The current LED remains based only on the latest sample. Periods longer than 24 hours may load more slowly because history is queried again on every dashboard refresh.

The configuration is stored as structured dashboard fields. JSON configurations created with version 1.0 are converted when the widget is opened and saved.

## Exemplos / Examples

```text
Ping: maior é pior; aviso 50; crítico 150
Ping indisponível: item de disponibilidade = Ping Ativo; crítico = 0; texto = Indisponível
Certificado: menor é pior; aviso 15; crítico 0
Disponibilidade: OK = 1; crítico = 0
```

## Autor / Author

**Daniel Carvalho**

[LinkedIn](https://www.linkedin.com/in/daniel-ti/) · [danielrc10@gmail.com](mailto:danielrc10@gmail.com)

Licença / License: [PolyForm Noncommercial 1.0.0](LICENSE) · [Aviso de uso / Usage notice](NOTICE.md)

Uso pessoal e não comercial é gratuito. Consultoria ou qualquer uso comercial exige autorização prévia de [Daniel Carvalho](mailto:danielrc10@gmail.com).

Personal and noncommercial use is free. Consulting or any commercial use requires prior authorization from [Daniel Carvalho](mailto:danielrc10@gmail.com).
